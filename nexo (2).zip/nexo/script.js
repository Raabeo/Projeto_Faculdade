const TERMS = [
  { term: "Firewall", text: "Barreira que monitora e controla o tráfego entre redes." },
  { term: "MFA", text: "Autenticação multifator que adiciona camadas à sua identidade." },
  { term: "Phishing", text: "Golpe que usa mensagens falsas para capturar informações." },
  { term: "Zero-day", text: "Vulnerabilidade ainda sem correção conhecida pelo fabricante." },
  { term: "Ransomware", text: "Malware que sequestra dados e exige resgate." },
  { term: "VPN", text: "Rede privada virtual que criptografa sua conexão." }
];

const QUESTIONS = [
  {
    q: "Você recebe um email urgente pedindo um código MFA. Qual é seu primeiro movimento?",
    options: ["Trocar a senha", "Desconectar e reportar", "Ignorar a mensagem"],
    correct: 1
  },
  {
    q: "Um site pede para desativar o antivírus para instalar um programa. Você:",
    options: ["Desativa na hora", "Recusa e procura fonte confiável", "Desativa só um pouco"],
    correct: 1
  },
  {
    q: "Qual a melhor forma de guardar senhas?",
    options: ["Mesma senha em tudo", "Anotar em papel perto do PC", "Gerenciador de senhas + MFA"],
    correct: 2
  }
];

let quizIndex = 0;
let quizScore = 0;

function initMenu() {
  const toggle = document.getElementById("menu-toggle");
  const links = document.getElementById("nav-links");
  if (!toggle || !links) return;

  toggle.addEventListener("click", function () {
    links.classList.toggle("is-open");
  });
}


function renderTerms(list) {
  const grid = document.getElementById("glossary-grid");
  grid.innerHTML = "";

  // ESTRUTURA 3 — LOOP (for...of)
  for (const item of list) {
    const card = document.createElement("article");
    card.innerHTML = "<span>TERM</span><h3>" + item.term + "</h3><p>" + item.text + "</p>";
    grid.appendChild(card);
  }

  
  if (list.length === 0) {
    grid.innerHTML = "<p style='color:#6b7a8d'>Nenhum termo encontrado.</p>";
  }
}

function initGlossary() {
  const input = document.getElementById("glossary-search");
  if (!input) return;
  renderTerms(TERMS);

  input.addEventListener("input", function () {
    const query = input.value.toLowerCase();
    // LOOP (filter) + CONDICIONAL (includes)
    const filtered = TERMS.filter(function (item) {
      return item.term.toLowerCase().includes(query) || item.text.toLowerCase().includes(query);
    });
    renderTerms(filtered);
  });
}

function loadQuestion() {
  const question = QUESTIONS[quizIndex];
  document.getElementById("quiz-number").textContent =
    "SIMULAÇÃO 0" + (quizIndex + 1) + " / 0" + QUESTIONS.length;
  document.getElementById("quiz-question").textContent = question.q;

  const box = document.getElementById("quiz-options");
  box.innerHTML = "";


  for (let i = 0; i < question.options.length; i++) {
    const btn = document.createElement("button");
    btn.textContent = String.fromCharCode(65 + i) + "  " + question.options[i];
    btn.setAttribute("data-testid", "quiz-option-" + i);
    btn.onclick = function () { selectOption(i); };
    box.appendChild(btn);
  }
}

function selectOption(index) {
  const question = QUESTIONS[quizIndex];
  const result = document.getElementById("quiz-result");
  const buttons = document.querySelectorAll("#quiz-options button");

  buttons.forEach(function (btn, i) {
    btn.classList.remove("selected");
    if (i === index) btn.classList.add("selected");
  });

 
  if (index === question.correct) {
    quizScore++;
    result.textContent = "✓ Correto! Essa é a resposta mais segura.";
    result.style.color = "#b8ff3d";
  } else {
    result.textContent = "✗ Quase. A resposta segura é: " + question.options[question.correct];
    result.style.color = "#ff536b";
  }
  result.classList.add("show");

  setTimeout(function () {
    quizIndex++;
    result.classList.remove("show");
    if (quizIndex < QUESTIONS.length) {
      loadQuestion();
    } else {
      showQuizEnd();
    }
  }, 2200);
}

function showQuizEnd() {
  const card = document.getElementById("quiz-card");
  card.innerHTML =
    "<div class='quiz-number'>RESULTADO FINAL</div>" +
    "<h2>Você acertou " + quizScore + " de " + QUESTIONS.length + ".</h2>" +
    "<p style='color:#6b7a8d'>" +
    (quizScore === QUESTIONS.length
      ? "Perfeito! Você está bem preparado contra phishing."
      : "Continue treinando — a atenção é sua melhor defesa.") +
    "</p>" +
    "<a class='primary-btn' href='quiz.html'>Tentar novamente</a>";
}

function initQuiz() {
  if (!document.getElementById("quiz-card")) return;
  quizIndex = 0;
  quizScore = 0;
  loadQuestion();
}

function initContact() {
  const form = document.getElementById("contact-form");
  if (!form) return;

  const saved = localStorage.getItem("nexo-contact");
  if (saved) {
    const data = JSON.parse(saved);
    document.getElementById("nome").value = data.nome || "";
    document.getElementById("email").value = data.email || "";
    document.getElementById("assunto").value = data.assunto || "";
    document.getElementById("mensagem").value = data.mensagem || "";
    showSuccess();
  }

  form.addEventListener("submit", function (event) {
    event.preventDefault();


    const data = {
      nome: document.getElementById("nome").value,
      email: document.getElementById("email").value,
      assunto: document.getElementById("assunto").value,
      mensagem: document.getElementById("mensagem").value
    };


    localStorage.setItem("nexo-contact", JSON.stringify(data));
    showSuccess();
  });
}

function showSuccess() {
  document.getElementById("contact-form").style.display = "none";
  document.getElementById("contact-success").classList.add("show");
}

document.addEventListener("DOMContentLoaded", function () {
  initMenu();
  initGlossary();
  initQuiz();
  initContact();
});