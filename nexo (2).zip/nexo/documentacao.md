## 📁 Estrutura de Pastas

```
/app/
├── frontend/
│   ├── public/
│   │   └── site/                 # ⭐ SITE ESTÁTICO (HTML/CSS/JS puros)
│   │       ├── index.html        # Início
│   │       ├── sobre.html        # Sobre
│   │       ├── ameacas.html      # Ameaças (tabela 4x4)
│   │       ├── boas-praticas.html
│   │       ├── ferramentas.html
│   │       ├── noticias.html
│   │       ├── glossario.html    # Busca com JS
│   │       ├── quiz.html         # Quiz interativo
│   │       ├── midia.html        # Vídeo + áudio nativos
│   │       ├── contato.html      # Formulário + localStorage
│   │       ├── css/
│   │       │   └── style.css     # CSS externo compartilhado
│   │       └── js/
│   │           └── main.js       # JS puro (4 estruturas)
│   └── src/                      # Versão React (SPA)
│       ├── components/layout/
│       ├── pages/
│       ├── data/
│       ├── styles/
│       └── App.js
└── backend/
    └── server.py
```

**Como acessar cada versão:**
- Site estático (abas separadas): `/site/index.html`, `/site/midia.html`, etc.
- App React (SPA): `/`